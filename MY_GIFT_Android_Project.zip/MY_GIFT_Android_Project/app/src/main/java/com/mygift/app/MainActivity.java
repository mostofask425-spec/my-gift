package com.mygift.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadDataWithBaseURL("file:///android_asset/", homePage(), "text/html", "UTF-8", null);
    }

    private String homePage() {
        return "<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>" +
            "<meta charset='utf-8'><title>MY GIFT</title><style>body{font-family:Arial;background:#f5f6fb;color:#202338;margin:0;padding:24px}" +
            ".box{max-width:480px;margin:12vh auto;background:white;padding:24px;border-radius:18px;text-align:center;box-shadow:0 4px 18px #0001}" +
            "h1{color:#6c4cf1}a{display:block;background:#6c4cf1;color:white;text-decoration:none;padding:15px;margin:14px 0;border-radius:10px;font-weight:bold}" +
            ".note{font-size:13px;color:#667085;line-height:1.5}</style></head><body><div class='box'><h1>🎁 MY GIFT</h1>" +
            "<p>Choose where to go</p><a href='file:///android_asset/customer.html'>Customer App</a>" +
            "<a href='file:///android_asset/admin.html'>Admin Panel</a>" +
            "<p class='note'>Prototype only. Login, payments, shared database, wallet and referral rewards are not live. Admin demo login: admin / gift123.</p>" +
            "</div></body></html>";
    }

    @Override public void onBackPressed() { super.onBackPressed(); }
}
