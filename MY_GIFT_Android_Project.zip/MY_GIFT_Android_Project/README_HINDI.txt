MY GIFT - Android WebView starter project

यह प्रोजेक्ट आपकी Customer और Admin HTML demo फाइलों को Android ऐप के अंदर खोलता है।

GitHub से APK बनाने के लिए:
1. इस ZIP की सभी फाइलें अपने GitHub repository की main branch में अपलोड करें।
   ZIP को repository में अकेली फाइल के रूप में अपलोड न करें; पहले ZIP extract करें।
2. Upload के बाद repository में Actions टैब खोलें।
3. “Build MY GIFT APK” workflow चुनें और “Run workflow” दबाएँ।
4. Build पूरा होने पर workflow run खोलें। नीचे Artifacts में “MY-GIFT-debug-apk” डाउनलोड करें।
5. ZIP artifact को extract करें; उसमें app-debug.apk मिलेगा। Android पर इंस्टॉल करने के लिए APK खोलें।

ध्यान दें:
- यह शुरुआती WebView APK project है, पूर्ण production app नहीं।
- Customer और Admin पेज अभी HTML demo हैं।
- असली login/OTP, सुरक्षित admin authentication, shared online database, payment verification,
  delivery/order backend, real wallet या referral payout जुड़े नहीं हैं।
- Admin demo credentials: admin / gift123. इन्हें production में इस्तेमाल न करें।
